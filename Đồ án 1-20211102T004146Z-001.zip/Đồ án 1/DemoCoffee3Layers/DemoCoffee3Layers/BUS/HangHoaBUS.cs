﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.DAL;

namespace DemoCoffee3Layers.BUS
{
    class HangHoaBUS
    {
        private HangHoaDAL hhDAL = new HangHoaDAL();

        public void Them(string maHH, string tenHH, int gia, String maDanhMuc)
        {
            hhDAL.Them(maHH, tenHH, gia, maDanhMuc);
        }

        public void Sua(string maHH, string tenHH, int gia, String maDanhMuc)
        {
            hhDAL.Sua(maHH, tenHH, gia, maDanhMuc);
        }

        public void Xoa(string maHH)
        {
            hhDAL.Xoa(maHH);
        }

        public List<String> LayDanhSach()
        {
            return hhDAL.LayDanhSach();
        }
    }
}
